package webtoon.controller;

import webtoon.api.TimeController;

public class ex {
    TimeController timeController = new TimeController();


}
