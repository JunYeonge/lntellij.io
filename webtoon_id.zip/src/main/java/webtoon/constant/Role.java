package webtoon.constant;

public enum Role {
    USER, ADMIN
}
