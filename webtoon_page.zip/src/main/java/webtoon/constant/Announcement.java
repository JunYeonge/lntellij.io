package webtoon.constant;

public enum Announcement {
    CONTENT,SERVICE
}