package spring_study.board_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
